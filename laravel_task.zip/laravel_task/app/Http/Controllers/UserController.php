<?php

namespace App\Http\Controllers;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class UserController extends Controller
{
    //
    public function signup(Request $req){
        $submit = $req['submit'];
        if($submit == 'submit'){
            $req->validate([
                'name' => 'required|regex:/^[a-zA-Z]+$/u',
                'email' => 'required|email|unique:users',
                'password' => 'required|min:8|confirmed',
            ]);

            $user = new User;
            $user->name = $req['name'];
            $user->email = $req['email'];
            $user->password = $req['password'];
            $user->save();

            return redirect('/login');

        }

        return view('/signup');
    }


    public function login(Request $req){
        $submit = $req['submit'];
        if($submit == 'submit'){
            $req->validate([
                'email' => 'required',
                'password' => 'required',
             
            ]);

            if(\Auth::attempt($req->only('email', 'password'))){
                return redirect('/index');
            }
            else{
                return redirect('/login')->withError('Incorrect Username or Password');
            }
        }
        return view('/login');
    }

    public function index(){
        $user = \Auth::user();

        return view('index', ['user' => $user]);  
    }

    public function logout(){
        \Session::flush();
        \Auth::logout();
        return redirect('/login');
    }
}
